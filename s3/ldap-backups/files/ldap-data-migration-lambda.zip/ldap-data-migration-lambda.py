#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import boto3
import zipfile
import io
import os

def lambda_handler(event, context):
    # Specify the details of the source S3 bucket and the file to be unzipped
    source_bucket = os.getenv("SOURCE_BUCKET")
    source_file_key = { "daily/", "hourly/"}

    # Specify the details of the destination S3 bucket
    destination_bucket = os.getenv("DESTINATION_BUCKET")

    # Set up S3 client
    s3 = boto3.client("s3")

    # Download the zip file from the source bucket
    download_path = '/tmp/file.zip'
    for key in source_file_key:
        s3.download_file(source_bucket, key, download_path)

    # Unzip the downloaded file
    extract_path = '/tmp/unzipped/'
    with zipfile.ZipFile(download_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)

    # Get the unzipped file name
    unzipped_file_name = os.listdir(extract_path)[0]
    unzipped_file_path = os.path.join(extract_path, unzipped_file_name)

    # Upload the unzipped file to the destination bucket
    destination_file_key = 'path/to/destination/file.ext'
    s3.upload_file(unzipped_file_path, destination_bucket, destination_file_key)

    
    return {
        "statusCode": 200,
        "body": "File unzipped and uploaded successfully. Data transfer completed."
    }

if __name__ == "__main__":
    handler(None, None)